# iran-bomber
sms bomber pro irani 🇮🇷v1 with Go (Golang)
<img src="screen/Screenshot_20230815-000720_Chrome.jpg">

<h3>views :</h3>
<br>
<img src="https://profile-counter.glitch.me/esfelurm/count.svg" alt="Visitors">

## Number of web services 

- Sms : 177 🧨
- Call : 6 🧨

## Speed +

## Support from [tested]
- `Linux` ✅
- `Windows` ✅
- `Termux` ✅


## screen shot

<img src="screen/IMG_20230815_002517_499.png">

## prerequisite :

- Windows : Download Golang programming language from reputable sites

- Linux : `sudo apt install golang`

- Termux : `pkg install golang`

## Run in windows

`Enter the Windows folder and run the sms.exe file`

## Run in Linux/Termux

```
git clone https://github.com/esfelurm/iran-bomber
cd iran-bomber
go run sms.go
```

 Good bye
