# sms-bomber
Simple &amp; powerful SMS/call-bomber with many APIs (for Iranian numbers)
