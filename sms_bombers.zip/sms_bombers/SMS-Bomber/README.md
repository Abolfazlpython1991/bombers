# SMS Bomber
SMS & Call bomber from iranian sites



## Sites that call
1. DigikalaJet

## Sites that send SMS
1. Dr.Next
2. Portal
3. Snapp
4. Sheypoor
5. SnapTaxi
6. Ghabzino
7. Divar
8. Football360
9. Virgool
10. SnappTrip
11. Taaghche
12. GapFilm
13. DigikalaJet
14. Kilid
15. Banimode
16. OstadKar
17. Technolife
18. HamrahMechanic
19. Mobit
20. Basalam
21. Miare
22. Vandar
23. Jabama
24. SnappMarket
25. Tikban
26. Buskool
27. Timcheh
28. Shavaz
29. Bama
30. Pinket
31. Gap 


## Setup
**Change phone_number in bomber.py**