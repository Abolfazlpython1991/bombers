# LasterBomber
i great bomber for iranian letsgo!

 <h1 align="center">LasterBomber- Discord : lasterfor3ver</h1>

<!-- ABOUT THE PROJECT -->
## About The Project

LasterBomber is a Powefull script made by lasterfor3ver with more than +200 API for iran
we highly recommend dont use this tools to Destruct people 

Note: this script is so powerfull so we dont have responsibility for using this tool so becarefull



 <!--Getting started -->

 ### Cmd for install Libraries

 This is an example of how to list things you need to use the software and how to install them.
* Install Required Libraries
  ```sh
  $ pip install user-agent
  $ pip install urllib3
     or
  $ pip install -r requirements.txt

  ```

### Installation

1. Clone the repo
   ```sh
   git clone https://github.com/mrd3f417/LasterBomber.git
   ```
2. Run in cmd when you insall all the Libraries
   ```
   python LasterBomber.py
   ```
3. Enter phone number / Like 09123456789

4. Enter the Speed / 0.1 for default

5. Enjoy (:



<!-- Our social links -->


