# sms bomber
<h3>❌ Tip: Use CTRL+C to finish! ❌</h3>
update : https://github.com/esfelurm/iran-bomber
<li>Powerful SMS to send consecutively to the target number!</li>
<li>Number of Sms web services: 200 </li>
<li>call web services: 3 </li>
<li>The ability to give the amount of SMS! </li>
<h4>This script is educational! Please do not abuse this tool <h4>
-----------------------------------------
<li>Running on Windows, Termux, Linux </li>

```
git clone https://github.com/esfelurm/sms_bomber
cd sms_bomber
python sms_bomber.py
```
<li> Channel Telegram : @esfelurm </li>
