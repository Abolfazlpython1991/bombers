 [![HitCount](http://hits.dwyl.com/aryainjas/iran-sms-bomber.svg?style=flat-square)](http://hits.dwyl.com/aryainjas/iran-sms-bomber)
[![CodeFactor](https://www.codefactor.io/repository/github/aryainjas/iran-sms-bomber/badge)](https://www.codefactor.io/repository/github/aryainjas/iran-sms-bomber)
![110957](https://user-images.githubusercontent.com/36337300/129598811-c7fe9ea5-2ed2-4e4b-8067-160442e64bb5.jpg)


# iran-sms-bomber
SMS-BOMBING Using python for Iranian cases.


# How to use
  you can use this script easy Af ,you only need PYTHON3 (sudo apt install python3 or download it from python.org)
  ![Arya-sms-bomb](https://user-images.githubusercontent.com/36337300/129579552-7f56da9b-ecce-446b-b23e-700a4a780538.png)
  
  
  
   use this command to start bombing the victim number :
        
        python3 Arya-sms-bomb.py 912***++// 
       
   ( do not enter the +98 , first 0 of mobile number and etc ...)
       you can edit the code to specify how much SMSs you want to send.
      
## Disclaimer
TO BE USED FOR EDUCATIONAL PURPOSES ONLY
**
        
          
The use of the iran-sms-bomber & etc ... is COMPLETE RESPONSIBILITY of the END-USER. Developer assume NO liability and is NOT responsible for any misuse or damage caused by this program.

"DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE."
<a href="https://nowpayments.io/donation?api_key=8NWRRT9-GWM4NDE-JXPJF75-74ZY5D0" target="_blank">
<img src="https://nowpayments.io/images/embeds/donation-button-black.svg" alt="Crypto donation button by NOWPayments">
</a>

