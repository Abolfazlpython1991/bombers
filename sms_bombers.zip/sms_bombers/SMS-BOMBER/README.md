**************************************************************
<h2>SMS - BOMBER 2024</h2>
<br>
<p align="left"> <h4 align="left">Languages and Tools:</h4><a href="https://www.python.org" target="_blank" rel="noreferrer"> <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/python/python-original.svg" alt="python" width="40" height="40"/> </a> </p>
<img src="Screenshot.png">
<br>
**************************************************************
<h3>How To Install :</h3>
<br>
## Open cmd & Terminal :
<br>
- git clone https://github.com/farbodXme/SMS-BOMBER.git
<br>
- cd SMS-BOMBER/sms
<br>
- pip install -r requirements.txt
<br>
- python main.py
- Set Phone Number With out ---> 0 <---  <h3>Example : ( 901****** )</h3>

<h2>views :</h2>
</br>
<img src="https://profile-counter.glitch.me/farbodXme/count.svg" alt="Visitors">
