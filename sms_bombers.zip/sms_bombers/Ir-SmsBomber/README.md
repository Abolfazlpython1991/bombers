# Ir-SmsBomber
This script sms bomber for iranian user
# Installation : 

```
apt-get install python3 git
git clone https://github.com/BlackFoxTM/Ir-SmsBomber
cd Ir-SmsBomber
pip3 install -r requirements.txt
python3 fox-ir_bomber.py
```
